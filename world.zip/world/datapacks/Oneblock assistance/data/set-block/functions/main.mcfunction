###################################################################
#                                                                 #
#             This Datapack was created by Lemonadefish           #
#                                                                 #
#     Email: Simon.Lemonadefish@gmail.com                         #
#                                                                 #
# --------------------------------------------------------------- #
#                         DATAPACK INFO                           #
# --------------------------------------------------------------- #
#                                                                 #
#     Author: Lemonadefish                                        #
#                                                                 #
###################################################################

setblock 245 71 245 minecraft:grass_block replace